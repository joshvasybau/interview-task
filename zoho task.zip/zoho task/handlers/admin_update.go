package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
)

func UpdateUserRole(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		var req struct {
			UserID int `json:"user_id"`
			RoleID int `json:"role_id"`
		}

		err := json.NewDecoder(r.Body).Decode(&req)
		if err != nil {
			http.Error(w, "Invalid request body", http.StatusBadRequest)
			return
		}

		_, err = db.Exec(
			"UPDATE users SET role_id = ? WHERE id = ?",
			req.RoleID, req.UserID,
		)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{
			"status": "user role updated successfully",
		})
	}
}
