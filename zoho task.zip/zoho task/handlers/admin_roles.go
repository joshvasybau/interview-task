package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
)

func GetRoles(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		rows, err := db.Query("SELECT id, name FROM roles")
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		defer rows.Close()

		var roles []map[string]interface{}

		for rows.Next() {
			var id int
			var name string

			rows.Scan(&id, &name)

			roles = append(roles, map[string]interface{}{
				"id":   id,
				"name": name,
			})
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(roles)
	}
}
