package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
)

func Login(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		w.Header().Set("Content-Type", "application/json")

		username := r.FormValue("username")
		password := r.FormValue("password")

		var roleID int
		var isAdmin bool

		err := db.QueryRow(`
			SELECT role_id, is_admin
			FROM users
			WHERE username=? AND password=?
		`, username, password).Scan(&roleID, &isAdmin)

		if err != nil {
			w.WriteHeader(http.StatusUnauthorized)
			json.NewEncoder(w).Encode(map[string]string{
				"error": "Invalid credentials",
			})
			return
		}

		json.NewEncoder(w).Encode(map[string]interface{}{
			"role_id":  roleID,
			"is_admin": isAdmin,
		})
	}
}
