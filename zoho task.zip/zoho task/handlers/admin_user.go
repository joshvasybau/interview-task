package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
)

func GetUsers(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		rows, err := db.Query("SELECT id, username, role_id FROM users")
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		defer rows.Close()

		var users []map[string]interface{}

		for rows.Next() {
			var id int
			var username string
			var role int

			err := rows.Scan(&id, &username, &role)
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}

			users = append(users, map[string]interface{}{
				"id":       id,
				"username": username,
				"role_id":  role,
			})
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(users)
	}
}
