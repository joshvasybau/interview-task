package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
	"strconv"

	"zoho-task/rbac"
)

func Transactions(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")

		roleID, err := strconv.Atoi(r.URL.Query().Get("role_id"))
		if err != nil {
			http.Error(w, "Invalid role_id", http.StatusBadRequest)
			return
		}

		if !rbac.CanUserAccess(db, roleID, "transactions", "view", "") {
			http.Error(w, "Access denied", http.StatusForbidden)
			return
		}

		rows, err := db.Query(`
			SELECT account_id, type, amount, created_at
			FROM transactions
			ORDER BY created_at DESC
		`)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		defer rows.Close()

		var result []map[string]interface{}

		for rows.Next() {
			var accountID int
			var txType string
			var amount float64
			var createdAt string

			err := rows.Scan(&accountID, &txType, &amount, &createdAt)
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}

			result = append(result, map[string]interface{}{
				"account_id": accountID,
				"type":       txType,
				"amount":     amount,
				"created_at": createdAt,
			})
		}

		json.NewEncoder(w).Encode(result)
	}
}
