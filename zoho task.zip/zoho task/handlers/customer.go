package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
	"strconv"

	"zoho-task/rbac"
)

func Customers(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")

		roleID, err := strconv.Atoi(r.URL.Query().Get("role_id"))
		if err != nil {
			http.Error(w, "Invalid role_id", http.StatusBadRequest)
			return
		}

		if !rbac.CanUserAccess(db, roleID, "customers", "view", "") {
			w.WriteHeader(http.StatusForbidden)
			return
		}

		rows, err := db.Query("SELECT name, email, phone FROM customers")
		if err != nil {
			http.Error(w, "Database query failed", http.StatusInternalServerError)
			return
		}
		defer rows.Close()

		var data []map[string]string

		for rows.Next() {
			var n, e, p string
			if err := rows.Scan(&n, &e, &p); err != nil {
				http.Error(w, "Database scan failed", http.StatusInternalServerError)
				return
			}
			data = append(data, map[string]string{
				"name":  n,
				"email": e,
				"phone": p,
			})
		}

		if err := rows.Err(); err != nil {
			http.Error(w, "Error iterating rows", http.StatusInternalServerError)
			return
		}

		json.NewEncoder(w).Encode(data)
	}
}
