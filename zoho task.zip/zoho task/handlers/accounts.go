package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
	"strconv"

	"zoho-task/rbac"
)

func Accounts(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")

		roleID, err := strconv.Atoi(r.URL.Query().Get("role_id"))
		if err != nil {
			http.Error(w, "Invalid role_id", http.StatusBadRequest)
			return
		}

		if !rbac.CanUserAccess(db, roleID, "accounts", "view", "") {
			w.WriteHeader(http.StatusForbidden)
			return
		}

		rows, err := db.Query(`
			SELECT 
				c.name,
				c.email,
				c.phone,
				a.account_number,
				a.balance
			FROM accounts a
			JOIN customers c ON a.customer_id = c.id
		`)
		if err != nil {
			http.Error(w, err.Error(), 500)
			return
		}
		defer rows.Close()

		var result []map[string]interface{}

		for rows.Next() {
			var name, email, phone, acc string
			var balance float64

			rows.Scan(&name, &email, &phone, &acc, &balance)

			result = append(result, map[string]interface{}{
				"name":           name,
				"email":          email,
				"phone":          phone,
				"account_number": acc,
				"balance":        balance,
			})
		}

		json.NewEncoder(w).Encode(result)
	}
}
