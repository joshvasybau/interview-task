package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
)

func GetPermissions(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		rows, err := db.Query(`
			SELECT roles.name, permissions.table_name, permissions.permissions
			FROM permissions
			JOIN roles ON permissions.role_id = roles.id
		`)
		if err != nil {
			http.Error(w, err.Error(), 500)
			return
		}
		defer rows.Close()

		var result []map[string]interface{}

		for rows.Next() {
			var role string
			var table string
			var perms string

			rows.Scan(&role, &table, &perms)

			result = append(result, map[string]interface{}{
				"role":        role,
				"table":       table,
				"permissions": perms,
			})
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(result)
	}
}
