package main

import (
	"net/http"
	"zoho-task/db"
	"zoho-task/handlers"

)

func main() {

	database := db.Connect()

	http.HandleFunc("/login", handlers.Login(database))

	http.HandleFunc("/customers", handlers.Customers(database))
	http.HandleFunc("/accounts", handlers.Accounts(database))
	http.HandleFunc("/transactions", handlers.Transactions(database))
	


	http.HandleFunc("/admin/permissions", handlers.GetPermissions(database))
    http.HandleFunc("/admin/users", handlers.GetUsers(database))
    http.HandleFunc("/admin/roles", handlers.GetRoles(database))
    http.HandleFunc("/admin/update-role", handlers.UpdateUserRole(database))

	http.Handle("/", http.FileServer(http.Dir("./frontend")))

	http.ListenAndServe(":8080", nil)
}
