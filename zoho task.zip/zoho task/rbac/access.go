package rbac

import (
	"database/sql"
	"encoding/json"
)

func CanUserAccess(
	db *sql.DB,
	roleID int,
	table string,
	action string,
	field string,
) bool {

	var permJSON string

	err := db.QueryRow(
		"SELECT permissions FROM permissions WHERE role_id=? AND table_name=?",
		roleID, table,
	).Scan(&permJSON)

	if err != nil {
		return false
	}

	var perm map[string]interface{}
	if err := json.Unmarshal([]byte(permJSON), &perm); err != nil {
		return false
	}

	// Table-level check
	if field == "" {
		tablePerm := perm["table"].(map[string]interface{})
		return tablePerm[action].(bool)
	}

	// Field-level check
	fields := perm["fields"].(map[string]interface{})
	if f, ok := fields[field]; ok {
		return f.(map[string]interface{})[action].(bool)
	}

	return false
}
